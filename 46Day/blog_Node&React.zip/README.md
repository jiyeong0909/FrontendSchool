* 해당 repo는 아래 link 영상 연습용 repo입니다.
* https://youtu.be/OML9f6LXUUs?list=PLj-4DlPRT48lGpll2kC4wOsLj7SEV_lYu