* https://youtu.be/tlTdbc5byAs tutorial
* 사용VSC extension : ES7 React/Redux/GraphQL/React-Native snippets
* function App() {  const currentUser = true; ... } 이 부분은 true와 false 2개로 나눠 실행됩니다.