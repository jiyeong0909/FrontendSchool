// rfc + Tab 누르시면 됩니다.
import './topbar.css'

export default function TopBar() {
    return (
        <div className="top">
            topbar
        </div>
    )
}
