import TopBar from "./topbar/TopBar";

function App() {
  const currentUser = true;
  return (
    <div>
      <TopBar/>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
      <p>blog</p>
    </div>
  );
}

export default App;
